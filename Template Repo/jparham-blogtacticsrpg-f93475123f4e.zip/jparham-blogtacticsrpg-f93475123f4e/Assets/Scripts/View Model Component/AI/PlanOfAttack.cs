﻿using UnityEngine;
using System.Collections;

public class PlanOfAttack 
{
	public Ability ability;
	public Targets target;
	public Point moveLocation;
	public Point fireLocation;
	public Directions attackDirection;
}
