﻿using UnityEngine;
using System.Collections;

public enum Locomotions
{
	Walk,
	Fly,
	Teleport
}