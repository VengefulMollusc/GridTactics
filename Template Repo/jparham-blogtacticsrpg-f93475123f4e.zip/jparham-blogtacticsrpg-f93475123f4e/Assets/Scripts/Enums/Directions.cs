﻿using UnityEngine;
using System.Collections;

public enum Directions
{
	North,
	East,
	South,
	West
}
