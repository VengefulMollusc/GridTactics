﻿using UnityEngine;
using System.Collections;

public enum Drivers
{
	None,
	Human,
	Computer
}
