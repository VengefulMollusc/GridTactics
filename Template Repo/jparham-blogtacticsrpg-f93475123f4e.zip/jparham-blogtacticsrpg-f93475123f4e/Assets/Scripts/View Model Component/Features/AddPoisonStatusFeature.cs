﻿using UnityEngine;
using System.Collections;

public class AddPoisonStatusFeature : AddStatusFeature<PoisonStatusEffect> 
{

}