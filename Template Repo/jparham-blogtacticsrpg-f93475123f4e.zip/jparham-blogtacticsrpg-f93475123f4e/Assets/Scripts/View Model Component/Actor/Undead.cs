﻿using UnityEngine;
using System.Collections;

public class Undead : MonoBehaviour 
{

}