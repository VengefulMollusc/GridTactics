﻿using UnityEngine;
using System.Collections;

public enum Targets
{
	None,
	Self,
	Ally,
	Foe,
	Tile
}