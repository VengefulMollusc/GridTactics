﻿using UnityEngine;
using System.Collections;

public class Merchandise : MonoBehaviour
{
	public int buy;
	public int sell;
}