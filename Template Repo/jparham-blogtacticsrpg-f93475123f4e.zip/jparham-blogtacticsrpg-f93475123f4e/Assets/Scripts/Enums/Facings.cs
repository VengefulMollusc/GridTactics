﻿using UnityEngine;
using System.Collections;

public enum Facings
{
	Front,
	Side,
	Back
}