﻿using UnityEngine;
using System.Collections;

public class Poolable : MonoBehaviour 
{
	public string key;
	public bool isPooled;
}